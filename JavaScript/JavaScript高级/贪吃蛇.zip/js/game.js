//主游戏对象
(() => {
    var that;
    //创建食物和蛇对象的构造函数
    function Game(map) {
        this.food = new Food();
        this.snake = new Snake();
        this.map = map;
        that = this;
    }
    //开始游戏方法
    Game.prototype.start = function() {
        //渲染食物和蛇
        this.food.render(this.map);
        this.snake.render(this.map);
        runSnake();
        //开始游戏逻辑
        //让蛇动起来
        //通过键盘控制蛇移动的方向
        //当蛇遇到食物 做相应的处理
        //当蛇遇到边界游戏结束
    };
    //让蛇润起来
    function runSnake() {
        var timer = setInterval(function() {
            //这里请注意this指向
            that.snake.move(that.food, that.map);
            that.snake.render(that.map);
            //当蛇遇到边界游戏结束
            //只需要判断蛇头的坐标即可
            let headX = that.snake.body[0].x;
            let headY = that.snake.body[0].y;
            let maxX = Math.floor(that.map.offsetWidth / that.snake.width);
            let maxY = Math.floor(that.map.offsetHeight / that.snake.height);
            if (headX >= maxX || headY >= maxY) {
                //设置异步，避免alert卡帧
                setTimeout(() => {
                    alert('你创到墙啦，游戏结束');
                }, 100);
                clearInterval(timer);
            }
            if (headX <= 0 || headY <= 0) {
                setTimeout(() => {
                    alert('你创到墙啦，游戏结束');
                }, 200);
                clearInterval(timer);
            }
            //判断是否吃到了自己
            snakeBody = that.snake.body;
            for (let i = 1; i < snakeBody.length; i++) {
                if ((snakeBody[0].x == snakeBody[i].x) && (snakeBody[0].y == snakeBody[i].y)) {
                    setTimeout(() => {
                        alert('你咬到自己啦，游戏结束');
                    }, 100);
                    clearInterval(timer);
                    break;
                }
            }
        }, 10);
    }
    //蛇控制
    function keyControl() {
        document.addEventListener('keyup', function(e) {
            switch (e.code) {
                case 'KeyD':
                    //蛇不能180度掉头
                    if (that.snake.direction != 'left') {
                        that.snake.direction = 'right';
                    }
                    break;
                case 'KeyA':
                    if (that.snake.direction != 'right') {
                        that.snake.direction = 'left';
                    }
                    break;
                case 'KeyS':
                    if (that.snake.direction != 'up') {
                        that.snake.direction = 'down';
                    }
                    break;
                case 'KeyW':
                    if (that.snake.direction != 'down') {
                        that.snake.direction = 'up';
                    }
                    break;
            }
        }, false); //事件冒泡

    }
    keyControl();
    //当蛇遇到食物 做相应的处理
    window.Game = Game;
})();

var map = document.querySelector('.map');
var game = new Game(map);
game.start();